#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
SOURCE="$ROOT/source"
LOCAL="$ROOT/.local"
PG_BIN='/Applications/Postgres.app/Contents/Versions/16/bin'
NODE_VERSION='v22.23.4'
NODE_SHA='efcc2b0db6f94bf53eddb038fe2b370277a042bd29e4f19b8f8e23598795b819'
fail() { printf '\n%s\nPress Return to close. ' "$1"; read -r unused || true; exit 1; }
trap 'fail "Startup stopped. Read the error above. Your saved data has not been deleted. Never share source/.env or .local/database-password."' ERR
[ "$(uname -s)" = Darwin ] && [ "$(uname -m)" = x86_64 ] || fail 'This starter is specifically for an Intel Mac running Monterey.'
if [ ! -x "$PG_BIN/postgres" ]; then
  printf 'Please install Postgres.app with PostgreSQL 16. Drag Postgres.app into Applications.\nYou do not need to click Initialize. Then double-click this starter again.\n'
  open 'https://github.com/PostgresApp/PostgresApp/releases/download/v2.9.6/Postgres-2.9.6-16.dmg'
  fail 'This replaces Docker with a normal Mac database application. Keep existing databases if you already have Postgres.app installed.'
fi
"$PG_BIN/postgres" --version >/dev/null
umask 077
mkdir -p "$LOCAL"
chmod 700 "$LOCAL"
copy_login() {
  awk -F= '$1=="DEV_AUTH_PASSWORD"{printf "%s",$2}' "$SOURCE/.env" | pbcopy
  printf '\nREADY! Email: creator@example.test\nYour private password is copied to your clipboard. Paste it into the browser using Command-V.\n'
  open 'http://localhost:3000/login'
}
LISTENERS=$(lsof -tiTCP:3000 -sTCP:LISTEN 2>/dev/null || true)
if [ -n "$LISTENERS" ]; then
  for pid in $LISTENERS; do
    cwd=$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1 || true)
    [ "$cwd" = "$SOURCE" ] || fail 'Another application is using port 3000. Close that application and try again.'
  done
  copy_login
  exit 0
fi
if ! mkdir "$LOCAL/starting" 2>/dev/null; then fail 'Another start is in progress. If interrupted, remove .local/starting and retry.'; fi
trap 'rmdir "$LOCAL/starting" 2>/dev/null || true' EXIT
RUNTIME="$LOCAL/node-$NODE_VERSION-darwin-x64"
if [ ! -x "$RUNTIME/bin/node" ]; then
  printf 'Downloading a verified Node.js version compatible with Monterey…\n'
  curl --fail --location --proto '=https' --tlsv1.2 -o "$LOCAL/node.tar.gz" "https://nodejs.org/dist/$NODE_VERSION/node-$NODE_VERSION-darwin-x64.tar.gz"
  printf '%s  %s\n' "$NODE_SHA" "$LOCAL/node.tar.gz" | shasum -a 256 --check
  tar -xzf "$LOCAL/node.tar.gz" -C "$LOCAL"
  rm "$LOCAL/node.tar.gz"
fi
export PATH="$RUNTIME/bin:$PG_BIN:$PATH"
export NODE_ENV=development
if [ ! -f "$LOCAL/database-password" ]; then openssl rand -hex 24 > "$LOCAL/database-password"; fi
chmod 600 "$LOCAL/database-password"
if [ ! -f "$SOURCE/.env" ]; then
  DB_PASSWORD=$(tr -d '\r\n' < "$LOCAL/database-password")
  (
    set -o noclobber
    {
      printf 'DATABASE_URL=postgresql://studio:%s@127.0.0.1:55432/studio?schema=public\n' "$DB_PASSWORD"
      printf 'REDIS_URL=redis://127.0.0.1:6380\nAUTH_URL=http://localhost:3000\nAUTH_MODE=development\n'
      printf 'AUTH_SECRET=%s\nDEV_AUTH_EMAIL=creator@example.test\nDEV_AUTH_PASSWORD=%s\n' "$(openssl rand -hex 32)" "$(openssl rand -hex 24)"
      printf 'LANGUAGE_PROVIDER=mock\nIMAGE_PROVIDER=mock\nVIDEO_PROVIDER=mock\nSTORAGE_DRIVER=local\nLOCAL_STORAGE_DIR=.local/assets\nSTUDIO_PRISMA_ENGINE=classic\nPRISMA_CLIENT_ENGINE_TYPE=library\n'
    } > "$SOURCE/.env"
  )
fi
chmod 600 "$SOURCE/.env"
if [ ! -f "$LOCAL/database/PG_VERSION" ]; then
  "$PG_BIN/initdb" -D "$LOCAL/database" -U studio --pwfile="$LOCAL/database-password" --auth=scram-sha-256 --encoding=UTF8 --no-locale
  printf "\nlisten_addresses = '127.0.0.1'\nport = 55432\nunix_socket_directories = ''\n" >> "$LOCAL/database/postgresql.conf"
fi
if ! "$PG_BIN/pg_ctl" -D "$LOCAL/database" status >/dev/null 2>&1; then
  "$PG_BIN/pg_ctl" -D "$LOCAL/database" -l "$LOCAL/database.log" -w -t 30 start
fi
export PGPASSWORD="$(tr -d '\r\n' < "$LOCAL/database-password")"
if [ "$("$PG_BIN/psql" -h 127.0.0.1 -p 55432 -U studio -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='studio'")" != 1 ]; then
  "$PG_BIN/createdb" -h 127.0.0.1 -p 55432 -U studio studio
fi
unset PGPASSWORD
cd "$SOURCE"
printf '\nPreparing your studio. The first start may take a few minutes.\n'
# Explicit Monterey compatibility preview; retain the repository's Node 24 requirement unchanged.
npm ci --engine-strict=false
npm run db:generate
npm run db:migrate
npm run db:seed
nohup "$RUNTIME/bin/node" "$SOURCE/node_modules/next/dist/bin/next" dev --hostname 127.0.0.1 --port 3000 > "$LOCAL/app.log" 2>&1 < /dev/null &
printf '%s\n' "$!" > "$LOCAL/app.pid"
READY=false
for attempt in $(seq 1 120); do
  if curl --silent --fail --max-time 3 http://localhost:3000/login >/dev/null 2>&1; then READY=true; break; fi
  if ! kill -0 "$(cat "$LOCAL/app.pid")" 2>/dev/null; then tail -30 "$LOCAL/app.log"; fail 'The studio could not start. Share the error message only, never your private files.'; fi
  sleep 2
done
[ "$READY" = true ] || fail 'Startup is taking longer than expected. Keep this folder and try Start Studio again in a minute.'
copy_login
printf '\nThe studio is private to this Mac. You can close this window. Use Stop Studio.command when finished.\n'
