#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
SOURCE="$ROOT/source"
PG_BIN='/Applications/Postgres.app/Contents/Versions/16/bin'
if [ -f .local/app.pid ]; then
  pid=$(cat .local/app.pid)
  case "$pid" in *[!0-9]*|'') exit 1;; esac
  cwd=$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1 || true)
  if [ "$cwd" = "$SOURCE" ]; then kill -TERM "$pid" 2>/dev/null || true; fi
fi
for pid in $(lsof -tiTCP:3000 -sTCP:LISTEN 2>/dev/null || true); do
  cwd=$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1 || true)
  if [ "$cwd" = "$SOURCE" ]; then kill -TERM "$pid" 2>/dev/null || true; fi
done
if [ -x "$PG_BIN/pg_ctl" ] && [ -f .local/database/PG_VERSION ]; then
  if "$PG_BIN/pg_ctl" -D "$ROOT/.local/database" status >/dev/null 2>&1; then "$PG_BIN/pg_ctl" -D "$ROOT/.local/database" -m fast -w stop; fi
fi
printf '\nStudio stopped. Your projects, characters and private credentials are saved.\n'
